<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="festival" tilewidth="16" tileheight="16" tilecount="1024" columns="32">
 <image source="suguruFestivals.png" width="512" height="512"/>
 <tile id="48">
  <animation>
   <frame tileid="48" duration="450"/>
   <frame tileid="49" duration="450"/>
   <frame tileid="50" duration="450"/>
   <frame tileid="49" duration="450"/>
  </animation>
 </tile>
 <tile id="53">
  <animation>
   <frame tileid="53" duration="450"/>
   <frame tileid="52" duration="450"/>
   <frame tileid="51" duration="450"/>
   <frame tileid="52" duration="450"/>
  </animation>
 </tile>
 <tile id="80">
  <animation>
   <frame tileid="80" duration="450"/>
   <frame tileid="81" duration="450"/>
   <frame tileid="82" duration="450"/>
   <frame tileid="81" duration="450"/>
  </animation>
 </tile>
 <tile id="239">
  <animation>
   <frame tileid="239" duration="1000"/>
   <frame tileid="240" duration="1000"/>
  </animation>
 </tile>
 <tile id="271">
  <animation>
   <frame tileid="271" duration="1000"/>
   <frame tileid="272" duration="1000"/>
  </animation>
 </tile>
 <tile id="288">
  <animation>
   <frame tileid="288" duration="750"/>
   <frame tileid="352" duration="750"/>
  </animation>
 </tile>
 <tile id="289">
  <animation>
   <frame tileid="289" duration="750"/>
   <frame tileid="353" duration="750"/>
  </animation>
 </tile>
 <tile id="320">
  <animation>
   <frame tileid="320" duration="750"/>
   <frame tileid="384" duration="750"/>
  </animation>
 </tile>
 <tile id="321">
  <animation>
   <frame tileid="321" duration="750"/>
   <frame tileid="385" duration="750"/>
  </animation>
 </tile>
</tileset>
