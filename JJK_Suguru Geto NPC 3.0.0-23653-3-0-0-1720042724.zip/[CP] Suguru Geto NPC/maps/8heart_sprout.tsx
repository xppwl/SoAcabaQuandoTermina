<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="outdoor spring" tilewidth="16" tileheight="16" tilecount="1975" columns="25">
 <image source="8heart_sprout.png" width="400" height="1264"/>
 <tile id="150">
  <animation>
   <frame tileid="150" duration="100"/>
   <frame tileid="150" duration="100"/>
   <frame tileid="150" duration="100"/>
   <frame tileid="150" duration="100"/>
   <frame tileid="150" duration="100"/>
   <frame tileid="150" duration="100"/>
   <frame tileid="150" duration="100"/>
   <frame tileid="420" duration="100"/>
   <frame tileid="421" duration="100"/>
   <frame tileid="422" duration="100"/>
   <frame tileid="423" duration="100"/>
   <frame tileid="422" duration="100"/>
   <frame tileid="421" duration="100"/>
   <frame tileid="422" duration="100"/>
   <frame tileid="423" duration="100"/>
   <frame tileid="150" duration="100"/>
   <frame tileid="150" duration="100"/>
   <frame tileid="150" duration="100"/>
  </animation>
 </tile>
 <tile id="151">
  <animation>
   <frame tileid="151" duration="1000"/>
   <frame tileid="152" duration="1000"/>
  </animation>
 </tile>
 <tile id="152">
  <animation>
   <frame tileid="151" duration="1000"/>
   <frame tileid="152" duration="1000"/>
  </animation>
 </tile>
</tileset>
