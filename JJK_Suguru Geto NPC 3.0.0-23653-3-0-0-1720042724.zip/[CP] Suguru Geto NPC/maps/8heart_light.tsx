<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="light" tilewidth="16" tileheight="16" tilecount="1368" columns="72">
 <image source="8heart_light.png" width="1152" height="312"/>
</tileset>
