<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="p" tilewidth="16" tileheight="16" tilecount="64" columns="4">
 <image source="../../../Content (unpacked)/Maps/paths" width="64" height="256"/>
</tileset>
