<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="untitled tile sheet" tilewidth="16" tileheight="16" tilecount="527" columns="17">
 <image source="suguruspring_beach.png" width="272" height="496"/>
 <tile id="7">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="8">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="18">
  <properties>
   <property name="Diggable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="19">
  <properties>
   <property name="Diggable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="20">
  <properties>
   <property name="Diggable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="21">
  <properties>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="22">
  <properties>
   <property name="Diggable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="23">
  <properties>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="24">
  <properties>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="25">
  <properties>
   <property name="Diggable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="26">
  <properties>
   <property name="Diggable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="41">
  <properties>
   <property name="Diggable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="42">
  <properties>
   <property name="Diggable" value="T"/>
   <property name="Spawnable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="43">
  <properties>
   <property name="Diggable" value="T"/>
  </properties>
 </tile>
 <tile id="51">
  <properties>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="52">
  <properties>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="53">
  <properties>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="54">
  <properties>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="56">
  <properties>
   <property name="Type" value="Stone"/>
  </properties>
 </tile>
 <tile id="58">
  <properties>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="59">
  <properties>
   <property name="Diggable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="68">
  <properties>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="69">
  <properties>
   <property name="Diggable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="70">
  <properties>
   <property name="Diggable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="71">
  <properties>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="75">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="80">
  <animation>
   <frame tileid="80" duration="600"/>
   <frame tileid="337" duration="600"/>
   <frame tileid="338" duration="600"/>
   <frame tileid="337" duration="600"/>
  </animation>
 </tile>
 <tile id="81">
  <properties>
   <property name="Type" value="Grass"/>
  </properties>
 </tile>
 <tile id="82">
  <properties>
   <property name="Type" value="Grass"/>
  </properties>
 </tile>
 <tile id="85">
  <properties>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="86">
  <properties>
   <property name="Diggable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="87">
  <properties>
   <property name="Diggable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="88">
  <properties>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="89">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="90">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="91">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="92">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="93">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="100">
  <properties>
   <property name="Type" value="Grass"/>
  </properties>
 </tile>
 <tile id="101">
  <properties>
   <property name="Type" value="Grass"/>
  </properties>
 </tile>
 <tile id="107">
  <properties>
   <property name="Type" value="Dirt"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="108">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="109">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="110">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="111">
  <properties>
   <property name="Type" value="Stone"/>
  </properties>
 </tile>
 <tile id="112">
  <properties>
   <property name="Type" value="Stone"/>
  </properties>
 </tile>
 <tile id="113">
  <properties>
   <property name="Type" value="Stone"/>
  </properties>
 </tile>
 <tile id="117">
  <properties>
   <property name="Type" value="Grass"/>
  </properties>
 </tile>
 <tile id="118">
  <properties>
   <property name="Type" value="Grass"/>
  </properties>
 </tile>
 <tile id="124">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="125">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="126">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="127">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="128">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="129">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="130">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="131">
  <properties>
   <property name="Passable" value="F"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="141">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
  <animation>
   <frame tileid="141" duration="250"/>
   <frame tileid="142" duration="250"/>
   <frame tileid="143" duration="250"/>
   <frame tileid="144" duration="250"/>
   <frame tileid="144" duration="250"/>
   <frame tileid="145" duration="250"/>
   <frame tileid="146" duration="250"/>
   <frame tileid="147" duration="250"/>
   <frame tileid="141" duration="250"/>
   <frame tileid="141" duration="250"/>
   <frame tileid="141" duration="250"/>
  </animation>
 </tile>
 <tile id="142">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="143">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="144">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="145">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="146">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="147">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="148">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="158">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
  <animation>
   <frame tileid="158" duration="250"/>
   <frame tileid="159" duration="250"/>
   <frame tileid="160" duration="250"/>
   <frame tileid="161" duration="250"/>
   <frame tileid="161" duration="250"/>
   <frame tileid="162" duration="250"/>
   <frame tileid="163" duration="250"/>
   <frame tileid="164" duration="250"/>
   <frame tileid="158" duration="250"/>
   <frame tileid="158" duration="250"/>
   <frame tileid="158" duration="250"/>
  </animation>
 </tile>
 <tile id="159">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="160">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="161">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="162">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="163">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="164">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="165">
  <properties>
   <property name="Passable" value="F"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="175">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
  <animation>
   <frame tileid="175" duration="250"/>
   <frame tileid="176" duration="250"/>
   <frame tileid="177" duration="250"/>
   <frame tileid="178" duration="250"/>
   <frame tileid="178" duration="250"/>
   <frame tileid="179" duration="250"/>
   <frame tileid="180" duration="250"/>
   <frame tileid="181" duration="250"/>
   <frame tileid="175" duration="250"/>
   <frame tileid="175" duration="250"/>
   <frame tileid="175" duration="250"/>
  </animation>
 </tile>
 <tile id="176">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="177">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="178">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="179">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="180">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="181">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="185">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="192">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
  <animation>
   <frame tileid="192" duration="250"/>
   <frame tileid="193" duration="250"/>
   <frame tileid="194" duration="250"/>
   <frame tileid="195" duration="250"/>
   <frame tileid="195" duration="250"/>
   <frame tileid="196" duration="250"/>
   <frame tileid="197" duration="250"/>
   <frame tileid="198" duration="250"/>
   <frame tileid="192" duration="250"/>
   <frame tileid="192" duration="250"/>
   <frame tileid="192" duration="250"/>
  </animation>
 </tile>
 <tile id="193">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="194">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="195">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="196">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="197">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="198">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="202">
  <properties>
   <property name="Diggable" value="T"/>
  </properties>
 </tile>
 <tile id="203">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="209">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
  <animation>
   <frame tileid="209" duration="250"/>
   <frame tileid="210" duration="250"/>
   <frame tileid="211" duration="250"/>
   <frame tileid="212" duration="250"/>
   <frame tileid="212" duration="250"/>
   <frame tileid="213" duration="250"/>
   <frame tileid="214" duration="250"/>
   <frame tileid="215" duration="250"/>
   <frame tileid="209" duration="250"/>
   <frame tileid="209" duration="250"/>
   <frame tileid="209" duration="250"/>
  </animation>
 </tile>
 <tile id="210">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="211">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="212">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="213">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="214">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="215">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="216">
  <animation>
   <frame tileid="216" duration="1000"/>
   <frame tileid="267" duration="1000"/>
  </animation>
 </tile>
 <tile id="217">
  <animation>
   <frame tileid="217" duration="1000"/>
   <frame tileid="268" duration="1000"/>
  </animation>
 </tile>
 <tile id="218">
  <animation>
   <frame tileid="218" duration="1000"/>
   <frame tileid="269" duration="1000"/>
  </animation>
 </tile>
 <tile id="226">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
  <animation>
   <frame tileid="226" duration="250"/>
   <frame tileid="227" duration="250"/>
   <frame tileid="228" duration="250"/>
   <frame tileid="229" duration="250"/>
   <frame tileid="229" duration="250"/>
   <frame tileid="230" duration="250"/>
   <frame tileid="231" duration="250"/>
   <frame tileid="232" duration="250"/>
   <frame tileid="226" duration="250"/>
   <frame tileid="226" duration="250"/>
   <frame tileid="226" duration="250"/>
  </animation>
 </tile>
 <tile id="227">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="228">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="229">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="230">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="231">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="232">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="233">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="234">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="235">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="243">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
  <animation>
   <frame tileid="243" duration="250"/>
   <frame tileid="244" duration="250"/>
   <frame tileid="245" duration="250"/>
   <frame tileid="246" duration="250"/>
   <frame tileid="246" duration="250"/>
   <frame tileid="247" duration="250"/>
   <frame tileid="248" duration="250"/>
   <frame tileid="249" duration="250"/>
   <frame tileid="243" duration="250"/>
   <frame tileid="243" duration="250"/>
   <frame tileid="243" duration="250"/>
  </animation>
 </tile>
 <tile id="244">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="245">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="246">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="247">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="248">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="249">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="250">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="251">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="252">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="260">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
  <animation>
   <frame tileid="260" duration="250"/>
   <frame tileid="261" duration="250"/>
   <frame tileid="262" duration="250"/>
   <frame tileid="263" duration="250"/>
   <frame tileid="263" duration="250"/>
   <frame tileid="264" duration="250"/>
   <frame tileid="265" duration="250"/>
   <frame tileid="266" duration="250"/>
   <frame tileid="260" duration="250"/>
   <frame tileid="260" duration="250"/>
   <frame tileid="260" duration="250"/>
  </animation>
 </tile>
 <tile id="261">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="262">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="263">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="264">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="265">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="266">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="277">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="278">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="279">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="280">
  <properties>
   <property name="Type" value="Dirt"/>
  </properties>
 </tile>
 <tile id="297">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="298">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="299">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="300">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="301">
  <properties>
   <property name="Passable" value="T"/>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="302">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="334">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="335">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="336">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="339">
  <properties>
   <property name="Passable" value="F"/>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="373">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="419">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="420">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="421">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="423">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="424">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="435">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="440">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="441">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="453">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="454">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="455">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="458">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="470">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="471">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="472">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="475">
  <properties>
   <property name="Water" value="T"/>
  </properties>
 </tile>
 <tile id="487">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="488">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="489">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="491">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="504">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="505">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="506">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
 <tile id="508">
  <properties>
   <property name="Type" value="Wood"/>
  </properties>
 </tile>
</tileset>
